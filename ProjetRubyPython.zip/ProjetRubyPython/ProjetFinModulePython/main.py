#!C:\Python310\python.exe
import boto3
import cgi
import cgitb
cgitb.enable()
form= cgi.FieldStorage()
fraudDetector = boto3.client('frauddetector')
print("Content-type: text/html; charset=utf-8")
class UserData:
    def __init__(self,ipAddress,email,billingState,agentUser,billingPoste,numberPhone,eventTam,billingAddress,eventLabel):
        self.ipAddress= ipAddress
        self.email = email
        self.billingState = billingState
        self.agentUser = agentUser
        self.billingPoste = billingPoste
        self.numberPhone = numberPhone
        self.eventTam = eventTam
        self.billingAddress = billingAddress
        self.eventLabel = eventLabel
    
    def getParametersFormIpAddress(self):
        while self.ipAddress == "":
            self.ipAddress = str(form.getvalue('ip_address'))
            if not self.ipAddress == "":
                return self.ipAddress
    def getParametersFormEmail(self):
        while self.email == "":
            self.email = str(form.getvalue('Email'))
            if not self.email == "":
                return self.email
    def getParametersFormBilState(self):
        while self.billingState == "":
            self.billingState = str(form.getvalue('billing_state'))
            if not self.billingState == "":
                return self.billingState
    def getParametersFormUserAgent(self):
        while self.agentUser == "":
            self.agentUser = str(form.getvalue('User_agent'))
            if not self.agentUser == "":
                return self.agentUser
    def getParametersFormBilBilPostal(self):
        while self.billingPoste == "":
            self.billingPoste = str(form.getvalue('billing_postal'))
            if not self.billingPoste == "":
                return self.billingPoste
    def getParametersFormNumPhone(self):
        while self.numberPhone == "":
            self.numberPhone = str(form.getvalue('phone_number'))
            if not self.numberPhone == "":
                return self.numberPhone
    def getParametersFormEventTam(self):
        while self.eventTam == "":
            self.eventTam  = str(form.getvalue('event_timestamp'))
            if not self.eventTam  == "":
                return self.eventTam
    def getParametersFormBilAddress(self):
        while self.billingAddress == "":
            self.billingAddress = str(form.getvalue('billing_address'))
            if not self.billingAddress  == "":
                return self.billingAddress 
    def getParametersFormEventLabel(self):
        while self.eventLabel == "":
            self.eventLabel = str(form.getvalue('event'))
            if not self.eventLabel  == "":
                return self.eventLabel
    def affichierUserData(self):
        print(f"\n\t Information sur User DATA  :\n\tIP_Addresse  :%s\n\t Email_Address :%s\n\t Billing_State :%s\n\t User_Agent :%s\n\t Billing_Postal :%s\n\t Number_Phone :%s\n\t Evente_TimesTamp :%s\n\t Billing_Address :%s\n\t Event_Label :%s" %(self.ipAddress,self.email,self.billingState,self.agentUser,self.billingPoste,self.numberPhone,self.eventTam,self.billingAddress,self.eventLabel))
ipadd = str(form.getvalue('ip_address'))
em = str(form.getvalue('Email'))
bilstate = str(form.getvalue('billing_state'))
user = str(form.getvalue('User_agent'))
bilPoste = str(form.getvalue('billing_postal'))
phoneNum = str(form.getvalue('phone_number'))
eventTime = str(form.getvalue('event_timestamp'))
bilAddresses = str(form.getvalue('billing_address'))
eventLabel = str(form.getvalue('event'))
userData = UserData(ipadd,em,bilstate,user,bilPoste,phoneNum,eventTime,bilAddresses,eventLabel)
userData.affichierUserData()
html = """<!DOCTYPE html>
<head>
        <title>Formulaire</title>
"""
print(html)
reponse=fraudDetector.get_event_prediction(
detectorId = 'sample_detector',
eventId = '802454d3-f7d8-482d-97e8-c4b6db9a0428',
eventTypeName = userData.getParametersFormEventTam(),
eventTimestamp = str(form.getvalue('event timestamp')),
entities = [{'entityType':'sample_client', 'entityId':'12345'}],
eventVariables = {'email':userData.getParametersFormEmail(),'ipaddress':userData.getParametersFormIpAddress()})
print('<h1>IPADDRESS :{}</h1>'.format(userData.getParametersFormIpAddress()))
print('<h1>EMAIL :{}</h1>'.format(userData.getParametersFormEmail()))
print('<h1>BILLING STATE :{}</h1>'.format(userData.getParametersFormBilState()))
print('<h1>AGENT USER :{}</h1>'.format(userData.getParametersFormUserAgent()))
print('<h1>BILLING POSTAL :{}</h1>'.format(userData.getParametersFormBilBilPostal()))
print('<h1>PHONE NUMBER :{}</h1>'.format(userData.getParametersFormNumPhone()))
print('<h1>EVENT TIMESTAM:{}</h1>'.format(userData.getParametersFormEventTam()))
print('<h1>BILLING ADDRESS :{}</h1>'.format(userData.getParametersFormBilAddress()))
print('<h1>EVENT LABEL :{}</h1>'.format(userData.getParametersFormEventLabel()))
print('<h1>Le score :{}</h1>'.format(reponse['score']))
html="""
</body>
</html>
"""
print(html)