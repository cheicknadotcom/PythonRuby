#coding:utf-8
import http.server
port =4110
address=("", port)
server=http.server.HTTPServer
handler=http.server.CGIHTTPRequestHandler
handler.cgi_directories=["/"]
httpd=server(address, handler)
print(f"serveur demarrer sur le port {port}")
httpd.serve_forever()