# coding:utf-8
import cgi
print("Content-type: text/html; charset=utf-8\n")
html = """<!DOCTYPE html>
   <html> <head>
    <meta charset="utf-8">
    <title>Formulaire</title>
    <style type="text/css" href="fonctionCss">
        *{
            margin: 0;
            padding: 0; 
        }
        body{
            background-image:url("ml.png");
            background-position: center;
            background-color:rgba(0,0,255,1)
            background-size:cover;
            font-family:Geneva;
            margin-top: 50px;
        }
        .enform{
            width: 600px;
            background-color:rgba(118, 135, 88, 0.6);
            background-image:url("ml.png");
            margin:auto;
            color: #ffffff;
            padding: 10px 0px 10px 0px;
            text-align: center;
            border-radius: 15px 15px 0px 0px;

        }
        .main{
            background-color: rgba(116, 126, 111, 0.4);
            background-image:url("ml.png");
            width: 600px;
            margin: auto;
        }
        form{
            padding: 10px;
            background-image:url("ml.png");
        }
        .address{
            margin-left: 25px;
            margin-top: 30px;
            width: 100px;
            color:#ffffff;
            font-size: 18px;
            font-weight: 600;
        }
        .ipaddress{
            position:relative;
            left: 200px;
            top: -20px; 
            line-height: 20px;
            border-radius: 5px;
            padding: 0 12px;
            font-size: 16px;
        }
        .Emailaddress{
            position:relative;
            left: 200px;
            top: -20px; 
            line-height: 20px;
            border-radius: 5px;
            padding: 0 12px;
            font-size: 16px;
        }
        .Billingstate{
            position:relative;
            left: 200px;
            top: -20px; 
            line-height: 20px;
            border-radius: 5px;
            padding: 0 12px;
            font-size: 16px;
        }
        .User_agent{
            position:relative;
            left: 200px;
            top: -20px; 
            line-height: 20px;
            border-radius: 5px;
            padding: 0 12px;
            font-size: 16px;
        }
        .billingpostal{
            position:relative;
            left: 200px;
            top: -20px; 
            line-height: 20px;
            border-radius: 5px;
            padding: 0 12px;
            font-size: 16px;
        }
        .number{
            position:relative;
            left: 200px;
            top: -20px; 
            line-height: 20px;
            border-radius: 5px;
            padding: 0 12px;
            font-size: 16px;
        }
        .eventtimestamp{
            position:relative;
            left: 200px;
            top: -20px; 
            line-height: 20px;
            border-radius: 5px;
            padding: 0 12px;
            font-size: 16px;
        }
        .billingaddress{
            position:relative;
            left: 200px;
            top: -20px; 
            line-height: 20px;
            border-radius: 5px;
            padding: 0 12px;
            font-size: 16px;
        }
        .option{
            position:relative;
            left: 200px;
            top: -20px; 
            line-height: 20px;
            border-radius: 5px;
            padding: 0 12px;
            font-size: 16px;
            overflow: hidden;
            outline: none;

        }
        .wrapper {
            margin: 20px 0px 0px 20px;
            text-align: center;
            width: 100%;
            position: relative;
        }
        .btn1 {
            padding: 10px 10px;
            background-color:bisque;
            border-radius: 6px;
            margin: 20px 0px 0px 20px;
            color: rgb(33, 32, 32);
            font-family: Geneva;
            text-align: center;
            position: relative;
            display:inline-block;
            border: 2px solid;
            cursor: pointer;
            transition: 0.25px;
        }
        .btn2 {
            padding: 10px 10px;
            background-color:beige;
            border-radius: 6px;
            margin: 20px 0px 0px 20px;
            color: rgb(33, 32, 32);
            font-family: Geneva;
            text-align: center;
            position: relative;
            display:inline-block;
            border: 2px solid;
            cursor: pointer;
            transition: 0.25px;
        }
        .btn2:hover{
            backgrou
            nd-color:  #fa1043;
        }
        .btn1:hover{
            background-color: rgb(30, 246, 18);
        }
        img{
            background-image:url("ml.png");
            background-position: left;
            background-color:rgba(0,0,255,1)
            background-size:cover;
            font-family:Geneva;
            margin-top: 50px;
        }
    </style> 
    </head>
    <body background-image='ml.png'>
        <img src="C:/Users/A/OneDrive/Bureau/ProjetFinModulePython/ml"
             alt="ia"
            srcset="C:/Users/A/OneDrive/Bureau/ProjetFinModulePython/ml 200w,
            C:/Users/A/OneDrive/Bureau/ProjetFinModulePython/ml.png 400w"
            sizes="(max-width: 600px) 200px, 50vw">
        <div class="enform"><h1>Enregistrement de compte</h1></div>
        <div class="main">
            <form enctype="multipart/form-data" action="main.py" method="post">
                <h2 class="address">Ip_Address:</h2>
                    <input class="ipaddress" type="text" name="ip_address">

                <h2 class="address">Email_Address:</h2>
                    <input class="Emailaddress" type="text" name="Email">

                <h2 class="address">Billing_State:</h2>
                    <input class="Billingstate" type="text" name="billing_state">

                <h2 class="address">User_Agent:</h2>
                    <input class="User_agent" type="text" name="User_agent">

                <h2 class="address">Billing_Postal:</h2>
                    <input class="billingpostal" type="text" name="billing_postal">

                <h2 class="address">Phone_Number:</h2>
                    <input class="number" type="text" name="phone_number">

                <h2 class="address">Event_Timestamp:</h2>
                    <input class="eventtimestamp" type="text" name="event_timestamp">

                <h2 class="address">Billing_Address:</h2>
                    <input class="billingaddress" type="text" name="billing_address">

                <h2 class="address">Event_Label</h2>
                    <select class="option" name="event">
                        <option>Legit</option>
                        <option>Fraud</option>
                    </select>
                <div class="wrapper">
                    <input type="submit" class="btn1 btn-info" name="envoyer" value="Enregistrer"/>
                    <input type="reset" class="btn2 btn-info" name="annuler" value="Annuler"/>
                </div> 
            </form>
        </div>
    </body>
</html>
"""
print(html)