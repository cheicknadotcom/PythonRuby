"""from asyncio.windows_events import NULL
from operator import is_not
typeoperation = ""
ma_liste = []
my_name = input("quel est votre nom ? ")
my_age = int(input("Quel est votre age ? "))
my_name=my_name.upper()
if my_name == "" and my_age != 0:
    print("s'il vous plait veuillez saisir un nom")
elif my_age == 0 or my_name == " " :
    print("Il faut saisir quelque chose s'il vous plait....")
else:         
    print("vous vous appellez " + my_name +" et " + "vous avez " + str(my_age) +" ans")

print("(:::Welcome in my calcutor :::)")
firtfloat = float(input("Entre le premier nombre svp : "))
secondfloat = float(input("Entre le dexieme nombre svp : "))

if my_name is not NULL and my_age != 0:
    typeoperation = input("Entre le type d'operation de calcul : ")
    if typeoperation == "+" or typeoperation == "addition":
        print("Le resultat de votre addition est :{} ".format(firtfloat + secondfloat))
    elif typeoperation == "-" or typeoperation == "soustraction":
        print("Le resultat de votre operation de soustraction est :{} ".format(firtfloat - secondfloat))
    elif typeoperation == "%" or typeoperation =="modulo":
        try:
            result = firtfloat %secondfloat
        except :
            print("IMPOSSIBLE DE MODULE PAR ZERO")
        else:
            print("Le resultat de votre operation de modulo est :{} ".format(result))
    elif typeoperation == "/" or typeoperation == "division":
        if secondfloat == 0 and firtfloat == 0:
            print("Impossible de faire cette division car le resultat est infinie....")
        elif secondfloat == 0 and firtfloat != 0:
            print("Impossible de divise par zero....")
        else:
            print("Le resultat de votre operation de division est : {}".format(firtfloat/secondfloat))
    elif typeoperation == "*" or typeoperation == "multiplication":
        print("Le resultat de votre operation de multiplication est :{}".format(firtfloat*secondfloat))
    else:
        print("Cette operation n'est pas definie pour le moment merci...")
def genere_number(n):
    for i in  range(0,100):
        ma_liste.append(n+i)
    return ma_liste
n = int(input("Entre un entier n : "))
print("les nombre de n incremente jusqu'a 100 est :{}".format(genere_number(n)))
print(genere_number(n))"""
"""
def factoriel(n):
    if n == 0:
        return 1
    else:
        return n*factoriel(n-1)
def carre_entier(n):
    return n**2
def  caree_cube_entier(n):
    return n**2, n**3
    
n = int(input("Entre intier pour calcule son factoriel :"))
print("Le factoriel de {} est : {}".format(n,factoriel(n)))
print("le carre de {} et cube {}".format(n,caree_cube_entier(n)))
print("le caree de {} est :{}".format(n,carre_entier(n)))"""


from random import random
import re


def demande_name():
    name = ""
    while name == "":
        first_name = input("Entre votre nom : ")
        try:
            name = first_name
        except :
            print("Saisir votre nom svp....")
    return name
def demande_last_name():
    prenom =""
    while prenom == "":
        last_name = input("Entre votre prenom : ")
        try:
            prenom = last_name
        except:
            print("Saisir votre prenom svp ....")
    return prenom
def demande_age():
    my_age = 0
    while my_age == 0:
        age = input("Entre votre age : ")
        try:
            my_age = age
        except:
            print("Saisir votre age svp....")
    return my_age
def demande_names(first_name):
    name = first_name
    while name == "":
        first_name = input("Entre votre nom : ")
        try:
            name = first_name
        except :
            print("Saisir votre nom svp....")
    return name
def demande_last_names(last_name):
    prenom = last_name
    while prenom == "":
        last_name = input("Entre votre prenom : ")
        try:
            prenom = last_name
        except:
            print("Saisir votre prenom svp ....")
    return prenom
def demande_ages(age):
    my_age = age
    while my_age == 0:
        age = input("Entre votre age : ")
        try:
            my_age = age
        except:
            print("Saisir votre age svp....")
    return my_age
def print_info_user():
    name_user = demande_name()
    last_name_user = demande_last_name()
    age_user = demande_age()
    print("Welcome in my application Mr.{} {} vous avez {} ans n'est pas.".format(name_user,last_name_user,age_user))
    test_age_user(age_user)
def  print_user_info(user_name,last_name_user,age_user,numero_user):
    print("Welcome in my application Mr.{} {} vous avez {} ans n'est pas et vous etes la personne N° {}".format(demande_names(user_name),demande_last_names(last_name_user),demande_ages(age_user),numero_user))
    test_age_user(age_user)
def test_age_user(age_users):
    age_user = int(age_users)
    if age_user < 10:
        print("WAOOOOO vous etes enfants super:::)")
    elif age_user < 18 and age_user > 10:
        print("Quelle chance vous etes mineur:::)")
    elif age_user == 18:
        print("Vous venez d'etre majeur cool ça non:::)")
    elif age_user > 18 and age_user < 60:
        print("Vous etes majeur vous pouvez vous marier:::)")
    elif age_user == 60:
        print("vous venez d'etre senior bravo:::)")
    elif age_user > 60:
        print("vous etes senior prepare la mort :::)")
    else:
        print("Cette personne n'existe pas merci:::)")
      
#print_info_user()
def recuperer_et_afficher_infos_user(numero_user):
    name_user_main = demande_name()
    last_name_main = demande_last_name()
    age_user_main = demande_age()
    print_user_info(name_user_main,last_name_main,age_user_main,numero_user)
"""  
for i in range(0,3):
    recuperer_et_afficher_infos_user(i)""" 
def produit(first_element,second_element):
    return int(first_element*second_element)
def table_de_multiplication(element_multiplier):
    min = 0
    max = 10
    if min > max:
        print("Impossible de creer cette table de multiplication:::)")
        exit(0)
    else:
        print(f"********************** la table de multiplication par {element_multiplier} **********************")
        for i in range(min+1,max+1):
            print("###### %s * %s = %s" %(i,element_multiplier,produit(i,element_multiplier)))
"""
nb_multiplier = 1
while not nb_multiplier == 0: 
    nb_multiplier = int (input("Entre le nombre a multiplier : "))          
    table_de_multiplication(nb_multiplier)"""
#definition de la classe Personne
class Personne:
    def __init__(self,nom):
        self.nom = nom
    def __init__(self,nom,age):
        self.nom = nom
        self.age = age
    def Sepresente(self):
        print(f"Bonjour je m'appelle {self.nom}, et j'ai {self.age} ans")
    def Generer_Personne():
        nom = input("Entre le nom de la personne : ")
        age = int(input("Entre l'age de la personne : "))
        person = Personne(nom,age)
        return person
    def Est_Majeur(self):
        if self.age > 18 :
            return True
        return False


#Utilisation de la classe Personne
"""
person = Personne.Generer_Personne()
person.Sepresente()
print("vous etes majeur si True ou mineur si False : %s" %(person.Est_Majeur()))"""
class Question:
    
    def __init__(self,titre_question="",reponse1="",reponse2="",reponse3="",reponse4="",solution="",score=0):
        self.titre_question = titre_question
        self.reponse1 = reponse1
        self.reponse2= reponse2
        self.reponse3 = reponse3
        self.reponse4 = reponse4
        self.solution = solution
        self.score = score
        if titre_question== "" and reponse1== "" and reponse2=="" and reponse3=="" and reponse4 == "" and solution == "":
            titre_question = self.Donne_titre_question()
            reponse1,reponse2,reponse3,reponse4 = self.GiveAnswhere()
            #solution = self.Solution_question()
            
    def GiveAnswhere(self):
        return input("Entre la reponse 1: "),input("Entre la reponse 2: "),input("Entre la reponse 3: "),input("Entre la reponse 4: ")
    
    def Solution_question(self):
        return input("Entre la solution de la question : ")
    
    def Donne_titre_question(self):
        while self.titre_question == "":
            self.titre_question = input("Entre le titre du question : ")
            if not self.titre_question == "":
                return self.titre_question
    def reseigne_attribut(titre_question,rep1,rep2,rep3,rep4,solution=""):
        question = Question (titre_question,rep1,rep2,rep3,rep4,solution)
        return question
    def question_info(self):
        print(f"\n\t Titre du Question :%s\n\t (a) :%s\n\t (b) :%s\n\t (c) :%s\n\t (d) :%s" %(self.titre_question,self.reponse1,self.reponse2,self.reponse3,self.reponse4))
        self.score_info()
        
    def score_info(self):
        reponse_user = input("Entre votre reponse : ")
        if reponse_user == self.Bonne_reponse():
            print("Bravo bonne reponse ")
            self.score += 1
        else:
            print("Mauvais reponse, il fallait donne {}".format(self.Bonne_reponse()))
    
    def Bonne_reponse(self):
        if self.titre_question == "Mali":
            return "Bamako".capitalize()
        elif  self.titre_question == "France":
            return "Paris".capitalize()
        elif  self.titre_question == "Senegal":
            return "Dakar".capitalize()
        elif  self.titre_question == "Furkina Faso":
            return "Ouaga".capitalize()
        else:
            return self.solution.capitalize()       
#question = Question()
#print(Question.Donne_titre_question())
list_question= []
"""nb_question = int(input("Entre le nombre de question souhaite svp : "))"""
"""parametre_tuple1,parametre_tuple2,parametre_tuple3,parametre_tuple4 = Question.GiveAnswhere()
solution_question=Question.Solution_question()
score = 0"""
"""
print(titre_questions)
print(*parametre_tuple)
print(solution_question)"""
"""for i in range(nb_question):
    question = Question(titre_questions,parametre_tuple1,parametre_tuple2,parametre_tuple3,parametre_tuple4,solution_question)
    user_solution = input("Entre votre solution : ")
    if user_solution == solution_question:
        score +=1
    print(list_question[i])   
print("Votre score est : {}".format(score))"""
for titre in range(2):
    titre_questions = input("Entre le Titre des Questions: ")
    reponse1 = input("Entre la premiere reponse: ")
    reponse2 = input("Entre la deuxieme reponse: ")
    reponse3 = input("Entre la troisieme reponse: ")
    reponse4 = input("Entre la quatrieme reponse: ")
    list_question.append(Question.reseigne_attribut(titre_questions,reponse1,reponse2,reponse3,reponse4))
    score =list_question[titre].score_info()


for questions in list_question:
    questions.question_info()
    #scores = questions.score_info()

print("votre score est :{}".format(score))