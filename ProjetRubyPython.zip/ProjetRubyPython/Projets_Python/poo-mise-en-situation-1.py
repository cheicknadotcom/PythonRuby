# POO EXERCICE DE MISE EN SITUATION 1
# genre
#   False : Femme
#   True  : Homme
class Personne:
    def __init__(self):
        self.Demande_info_personne()
    def __init__(self, nom: str ="", age: int = 0, genre: bool= False):
        self.nom = nom   # crée une variable d'instance : nom
        self.age = age
        self.genre = genre
        if self.nom =="" and self.age == 1:
            self.Demande_nom_personne()
        if self.nom == "":
            self.nom,self.age,self.genre = self.Demande_info_personne()
        print("Constructeur personne " + self.nom)
    def  Demande_nom_personne(self):
        return input("Entre le nom de la personne: ")
    def Demande_info_personne(self):
        return input("Entre le Nom : "), int(input("Entre l'age :")),bool(input("Entre le genre False pour la Femme et True Pour Homme :"))
    def SePresenter(self):
        # Bonjour, je m'appelle Jean, j'ai 30 ans
        # Je suis majeur
        self.Statut_Personne()
    def EstMajeur(self):
        return self.age >= 18
    def Statut_Personne(self):
        print("Bonjour, je m'appelle " + self.nom + ", j'ai " + str(self.age) + " ans")
        genre_personne="Masculin" if self.genre else "Feminin"
        e_miette ="" if self.genre else "e"
        var_statut = "Je suis majeur"+e_miette if self.EstMajeur() else "Je suis mineur"+e_miette
        print(genre_personne)
        print(var_statut)
    def generer_Personne():
          return Personne()
"""       
liste_personne = []
nb_personne = int(input("Donne le nombre de personne a creer :"))
for i in range(nb_personne):
    liste_personne.append(Personne.generer_Personne())
    
for i in range(nb_personne):
    liste_personne[i].Statut_Personne()"""
"""    
name = []

nom = "Null"
while not nom == "":
    nom = input("Entre le nom de l'utilisateur : ")
    if not nom == "":
        name.append(nom)

for i in name:
    name.sort()
    print("Nom :",i)"""
chauffeur_voiture=["moussa","van","Issa","lamine","madou","moustapha"]
distance_voiture = [1.2,2.2,0.3,4.4,1,2]

#cherchons la distance la plus courte et le chauffeur conserne

distance_courte =distance_voiture[0]
for distance in distance_voiture:
    if distance < distance_courte:
        distance_courte = distance
        id = distance_voiture.index(distance)
        print(chauffeur_voiture[id],distance)
    