module NsPersonnel
	class Addres
		def initialize(pays,ville,quartie,rue,port,email,password)
			@pays = pays
			@vile = ville
			@quartie = quartie
			@rue = rue
			@port = port
			@email = email
			@password = @password
		end
	end
	class Humain 
		#require_relative Addres
		attr_reader :nom, :prenom, :fonction, :id
		attr_writer :nom,:prenom,:fonction, :id
		@@NbreHumain = 0
		def initialize(id,nom,prenom,fonction,age)
			@id = id
			@nom = nom
			@prenom = prenom
			@fonction = fonction
			@age = age
			@@NbreHumain += 1
		end
		def  sePresenter
			puts "Je suis #{@nom} #{@prenom} et j'ai #{@age} ans j'exerce la fonction : #{@fonction} en se moment"
		end

		def  getid
			puts @id
		end
		def self.getNbreHumain
			puts @@NbreHumain
		end

	end
	class Personnel < Humain

	end
end
module Calcul
	class Calculator
		attr_reader :firstEnter,:secondEnter, :operation
		attr_writer :firstEnter,:secondEnter,:operation

		def initialize(firstEnter,secondEnter,operation)
			@firstEnter = firstEnter
			@secondEnter = secondEnter
			@operation = operation
		end
		def addition
			raise "La variable doit etre un nombre" if !@firstEnter.respond_to?(:to_f)
			raise "La variable doit etre un nombre" if !@secondEnter.respond_to?(:to_f)
			if @operation == "addion" || @operation == "+"
				@firstEnter.to_f + @secondEnter.to_f
			end
		end
		def soustraction
			raise "La variable doit etre un nombre" if !@firstEnter.respond_to?(:to_f)
			raise "La variable doit etre un nombre" if !@secondEnter.respond_to?(:to_f)
			if @operation == "soustraction" || @operation == "-"
				@firstEnter.to_f - @secondEnter.to_f
			end
		end
		def produit
			raise "La variable doit etre un nombre" if !@firstEnter.respond_to?(:to_f)
			raise "La variable doit etre un nombre" if !@secondEnter.respond_to?(:to_f)
			if @operation == "produit" || @operation == "*"
				@firstEnter.to_f * @secondEnter.to_f
			end
		end
		def modulo
			raise "La variable doit etre un nombre" if !@firstEnter.respond_to?(:to_f)
			raise "La variable doit etre un nombre" if !@secondEnter.respond_to?(:to_f)
			if @operation == "modulo" || @operation == "%"
				if @secondEnter != 0
					@firstEnter.to_f % @secondEnter.to_f
				else
					puts "Impossible de module par Zero..."
				end
			end
		end
		def division
			raise "La variable doit etre un nombre" if !@firstEnter.respond_to?(:to_f)
			raise "La variable doit etre un nombre" if !@secondEnter.respond_to?(:to_f)
			if @operation == "division" ||@operation == "/"
				rais "Impossible de faire la division par zero" if @secondEnter == 0
					@firstEnter.to_f / @secondEnter.to_f
			end
		end
		def getFirst
			@firstEnter
		end
		def getSecond
			@secondEnter
		end
		def getOperation
			@operation
		end
	end
end
humain = NsPersonnel::Humain.new(1,"Cheickna","Doumbia","Informaticien",24)
humain.sePresenter
humain.getid
humains = NsPersonnel::Humain.new(2,"Modibo","Doumbia","Mathematicien",15)
humains.sePresenter
humains.getid
pers = NsPersonnel::Personnel.new(3,"Diane","Sorgho","Gestionnaire",25)
pers.sePresenter

NsPersonnel::Humain.getNbreHumain
quite = "Non"
while quite == "Non" || quite == "N" || quite == "n"
	puts "Entre le premier entier svp :"
	premier = gets.chomp.to_f
	puts "Entre le deuxieme entier svp : "
	deuxieme  = gets.chomp.to_f
	puts "Entre votre operation svp : "
	op = gets.chomp.to_s
	cal = Calcul::Calculator.new(premier,deuxieme,op)
	raise "Operation doit etre une chaine de caractere svp" if !op.respond_to?(:to_s)
	if cal.getOperation == "addion" || cal.getOperation == "+"
		puts  "Le resultat : " + cal.addition.to_s
	elsif cal.getOperation == "soustraction" || cal.getOperation == "-"
		puts  "Le resultat : " + cal.soustraction.to_s
	elsif cal.getOperation == "multiplication" || cal.getOperation == "*"
		puts  "Le resultat : " + cal.produit.to_s
	elsif cal.getOperation == "modulo" || cal.getOperation == "%"
		puts  "Le resultat : " + cal.modulo.to_s
	elsif cal.getOperation == "division" || cal.getOperation == "/"
		puts  "Le resultat : " + cal.division.to_s
	else
		puts "Cette option n'existe pas pour le moment sory..."
	end

	puts "Voulez vous continue ? O/N"
	quite = gets.chomp.to_s
end
	
