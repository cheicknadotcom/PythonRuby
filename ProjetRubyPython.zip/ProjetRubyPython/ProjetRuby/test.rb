puts "-------------------------------------------------------------------------------"
chiffre_deviner = 100
rsultat =0
while rsultat != chiffre_deviner
	puts "Deviner le chiffre cacher si vous pouvez : "
	rsultat = gets.chomp.to_i
end
puts "bravo vous etes meilleur :)"

puts "-------------------------------------------------------------------------------"
puts "Entre votre Nom :"
nom = gets.chomp
puts "Entre votre Prenom :"
prenom = gets.chomp
puts "Entre votre age :"
age = gets.chomp.to_i
puts "Bonjour M.#{nom} #{prenom} vous avez #{age} ans n'est pas"
puts "-------------------------------------------------------------------------------"
puts "Entre inverse  de #{nom} :"
mot = gets.chomp.to_s
if mot.reverse == mot
	puts "bravo vous l'avez trouve #{mot} inverse"
else
	puts "Desole vous n'avez pas trouve l'inverse de  #{mot}"
end
puts "-------------------------------------------------------------------------------"
puts "Okay #{nom} Entre un entier de test pair : "
entier = gets.chomp.to_i
unless !entier.even?
 	puts "Votre entier #{entier} est bien pair"
else 
	puts "Votre entier #{entier} est bien impair"
end
puts "-------------------------------------------------------------------------------"