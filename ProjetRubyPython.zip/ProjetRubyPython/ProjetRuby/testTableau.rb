list_etudiant = ["Cheickna","Doumbia","Note","Classe"]
list_etudiant[3] = {classe1:1,classe2:2,classe3:3,classe4:4,classe5:5,classe6:6,classe7:7,classe8:8,classe9:9}
list_etudiant[0]=["cheickna Doumbia","Modibo Doumbia","Moussa Doumbia","Drissa Doumbia"]
 puts list_etudiant.length
while list_etudiant.length.to_i > 0
	for i in 1..list_etudiant.length()
	list_etudiant.each {|element| puts element}
	end
	list_etudiant.length -= 1
end

