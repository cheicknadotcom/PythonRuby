module PersonContact
	class Contact
		@@stockage = []
		attr_reader :id,:nom,:prenom,:email,:password,:tel
		attr_writer :id,:nom,:prenom,:email,:password,:tel
		def initialize(id,nom,prenom,email,password,tel)
			@id = id.to_f
			@nom = nom.to_s
			@prenom = prenom.to_s
			@email = email.to_s
			@password = password.to_s
			@tel = tel.to_s
		end 
		def self.ajouterContact(cont)
			@@stockage << cont 
		end
		def self.delContact(id)
			raise "Mauvais valeur pour id" if id.respond_to?(:to_f)
			@@stockage.delete_if{|n| n = id}
		end
		def afficherContact()
			puts "Le contact :\n\t Id :#{@id}\n\t Nom:#{@nom}\n\t Prenom :#{@prenom}\n\t Email :#{@email}\n\t password :#{@password}\n\t Telephone : #{@tel}"
		end
		def getId
			@id
		end
		def getNom
			@nom
		end

		def self.affichersListe
			@@stockage.each {|element| element.afficherContact}
		end
	end
end

#pers = PersonContact::Contact.new(1.0,"Cheickna","Doumbia","cheicknadoumbia100@gmail.com","j'aimeMamere","00774437898")

#puts pers.inspect

#PersonContact::Contact.ajouterContact(pers)

#pers.afficherContact
#pers.delContact(pers.getId)
#pers.afficherContact
for i in 1...3
	puts  "Entre l'identifiant du Contact :"
	id = gets.chomp.to_f
	puts "Entre le Nom du Contact :"
	nom = gets.chomp.to_s
	puts "Entre le Prenom du Contact : "
	prenom = gets.chomp.to_s
	puts "Entre Email du Contact : "
	email = gets.chomp.to_s
	puts "Entre le mot de pass du Contact :"
	password = gets.chomp.to_s
	puts "Entre le Numero du Contact :"
	tel = gets.chomp.to_s
	pers =PersonContact::Contact.new(id,nom,prenom,email,password,tel)
	PersonContact::Contact.ajouterContact(pers)
end
   PersonContact::Contact.affichersListe
   PersonContact::Contact.delContact(12)
   PersonContact::Contact.affichersListe
