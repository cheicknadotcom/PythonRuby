def somme_entiers(firstEnter,secondEnter)
	if firstEnter.respond_to?(:to_f) && secondEnter.respond_to?(:to_f)
		return (firstEnter.to_f + secondEnter.to_f)
	end
end
def soustraction_entiers(firstEnter,secondEnter)
	if firstEnter.respond_to?(:to_f) && secondEnter.respond_to?(:to_f)
		return (firstEnter.to_f - secondEnter.to_f)
	end
end
def module_entiers(firstEnter,secondEnter)
	if firstEnter.respond_to?(:to_f) && secondEnter.respond_to?(:to_f)
		return (firstEnter.to_f % secondEnter.to_f)
	end

end
def division_entiers(firstEnter,secondEnter)
	if firstEnter.respond_to?(:to_f) && secondEnter.respond_to?(:to_f)
		if secondEnter != 0
			return (firstEnter.to_f / secondEnter.to_f)
		else
			puts "Impossible de divise par zero"
		end
	end
end
def somme(firstEnter,secondEnter)
	if firstEnter.respond_to?(:to_f) && secondEnter.respond_to?(:to_f)
		return (firstEnter.to_f + secondEnter.to_f)
		end
end

puts "########Welcome on my calculator########"

puts "Entre le premier entier :"
first = gets.chomp

puts "Entre le premier entier :"
second =gets.chomp.to_f

puts "La soustraction est : #{soustraction_entiers(first,second)}"
puts "La somme est : #{somme_entiers(first,second)}"
puts "La dision est : #{division_entiers(first,second)}"
puts "La Modulo est : #{module_entiers(first,second)}"