class Personne
	def  initialize(nom,prenom,age)
		@nom = nom
		@prenom = prenom
		@age = age		
	end
	def  bonjour
		puts "Bonjour je m'appelle #{@nom} #{@prenom}et j'ai #{@age} ans"
	end
	def sePresente
		puts "Bienvenu Monsieur presentez vous svp"
		if @age <= 1
			puts "Je suis m.#{@nom} #{@prenom} et j'ai #{@age} an "
		else
			puts "Je suis m.#{@nom} #{@prenom} et j'ai #{@age} ans "
		end	
	end
	def isMajeur
		if @age > 18
			puts "waoooh #{@nom} vous etes majeur..."
		elsif @age < 18
			puts "Desole #{@nom} vous etes minieur..."
		else
			puts "Okay #{@nom} vous venez d'etre majeur"
		end
	end
end

pers = Personne.new("cheickna","Doumbia",27)
person = Personne.new("Moussa","Doumbia",1)
puts "First Person is:"
pers.bonjour
puts "Second Person is:"
person.bonjour
puts "##########################################################################"
pers.isMajeur
person.isMajeur
puts "##########################################################################"
pers.sePresente
person.sePresente